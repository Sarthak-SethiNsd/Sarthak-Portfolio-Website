import { PageIntro } from "@/components/PageIntro";
import { ProjectCard } from "@/components/ProjectCard";
import { getProjects } from "@/lib/content";

export const metadata = { title: "Projects" };

export default async function ProjectsPage() {
  const projects = await getProjects();
  return (
    <>
      <PageIntro description="Products documented as living systems—each iteration, decision, and lesson has a place." eyebrow="Build archive · 03" title="Selected projects" />
      {projects.length ? <div className="project-grid">{projects.map((project) => <ProjectCard key={project.slug} project={project} />)}</div> : <div className="center-state"><h2>No projects available yet.</h2><p>Add a folder under data/projects to publish one.</p></div>}
    </>
  );
}
