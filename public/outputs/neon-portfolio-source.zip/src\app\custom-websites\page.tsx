import { ArrowUpRight, CakeSlice, Heart } from "lucide-react";
import Link from "next/link";
import { PageIntro } from "@/components/PageIntro";

export const metadata = { title: "Custom Websites" };

const services = [
  { href: "/custom-websites/birthday", title: "Birthday Websites", text: "Joyful, personal story spaces for a once-a-year celebration.", icon: CakeSlice, tone: "cyan" },
  { href: "/custom-websites/anniversary", title: "Anniversary Websites", text: "Elegant digital keepsakes for shared milestones and memories.", icon: Heart, tone: "magenta" },
];

export default function CustomWebsitesPage() {
  return <><PageIntro description="Made-to-measure digital keepsakes for moments worth revisiting, designed with warmth and a little magic." eyebrow="Digital studio · 04" title="Custom websites" /><div className="service-grid">{services.map(({ href, title, text, icon: Icon, tone }) => <Link className={`service-card ${tone}`} href={href} key={href}><Icon aria-hidden="true" /><p className="eyebrow">Personalized experience</p><h2>{title}</h2><p>{text}</p><span>Explore service <ArrowUpRight size={17} /></span></Link>)}</div></>;
}
