import { ArrowLeft, ArrowUpRight, MessageCircle } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Panel } from "@/components/Panel";
import { getService } from "@/lib/content";

interface ServicePageProps { params: Promise<{ slug: string }> }
const allowed = ["birthday", "anniversary"];
export function generateStaticParams() { return allowed.map((slug) => ({ slug })); }
export async function generateMetadata({ params }: ServicePageProps): Promise<Metadata> { const service = await getService((await params).slug); return { title: service?.title ?? "Custom Website" }; }

export default async function ServicePage({ params }: ServicePageProps) {
  const service = await getService((await params).slug);
  if (!service || !allowed.includes(service.slug)) notFound();
  return <><Link className="back-link" href="/custom-websites"><ArrowLeft size={16} /> Custom websites</Link><header className="service-hero"><p className="eyebrow">{service.eyebrow}</p><h1>{service.title}</h1><p>{service.description}</p></header><div className="service-detail-grid"><Panel title="Possible features"><ul className="feature-cloud">{service.features.map((feature) => <li key={feature}>{feature}</li>)}</ul></Panel><Panel title="Sample experiences">{service.samples.length ? <div className="sample-grid">{service.samples.map((sample) => <a href={sample.url} key={sample.title} rel="noreferrer" target="_blank"><div><Image alt={sample.imageAlt} fill sizes="400px" src={sample.image} /></div><span>{sample.title}<ArrowUpRight size={16} /></span></a>)}</div> : <p>No samples published yet.</p>}</Panel></div><aside className="contact-note"><MessageCircle aria-hidden="true" /><div><p className="eyebrow">Planning note</p><p>{service.contactNote}</p></div></aside></>;
}
